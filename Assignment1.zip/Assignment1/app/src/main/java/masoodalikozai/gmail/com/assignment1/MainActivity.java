package masoodalikozai.gmail.com.assignment1;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText stdID_EditText;
    EditText courseCode_EditText;
    EditText totalMarks_EditText;
    Button showGrade_Button;

    TextView studentID_TextView;
    TextView courseCode_TextView;
    TextView totalMarks_TextView;
    TextView grade_TextView;
    TextView studentID_TextView2;
    TextView courseCode_TextView2;
    TextView totalMarks_TextView2;
    TextView grade_TextView2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//The Show Grade button
        showGrade_Button = findViewById(R.id.showGrade_Button);
        showGrade_Button.setOnClickListener(
                new Button.OnClickListener() {
                    public void onClick(View v) {
                        stdID_EditText = findViewById(R.id.stdID_EditText);
                        courseCode_EditText = findViewById(R.id.courseCode_EditText);
                        totalMarks_EditText = findViewById(R.id.totalMarks_EditText);
                        studentID_TextView = findViewById(R.id.studentID_View);
                        courseCode_TextView = findViewById(R.id.courseCode_View);
                        totalMarks_TextView = findViewById(R.id.totalMarks_View);
                        grade_TextView = findViewById(R.id.grade_View);
                        studentID_TextView2 = findViewById(R.id.studentID_View2);
                        courseCode_TextView2 = findViewById(R.id.courseCode_View2);
                        totalMarks_TextView2 = findViewById(R.id.totalMarks_View2);
                        grade_TextView2 = findViewById(R.id.grade_View2);

                        String stdID_Input = stdID_EditText.getText().toString();
                        String courseCode_Input = courseCode_EditText.getText().toString();

                        if (TextUtils.isEmpty(stdID_EditText.getText().toString()) || TextUtils.isEmpty(courseCode_EditText.getText().toString()) || TextUtils.isEmpty(totalMarks_EditText.getText().toString())) {
                            Toast.makeText(getApplicationContext(), "Please fill all the fields", Toast.LENGTH_SHORT).show();
                            return;

                        } else {

                            Double totalMarks_Input = Double.parseDouble(""+totalMarks_EditText.getText());


                            if (totalMarks_Input > 100) {
                                Toast.makeText(getApplicationContext(), "Marks can NOT be greater than 100", Toast.LENGTH_SHORT).show();
                            } if (totalMarks_Input >= 94 && totalMarks_Input <= 100) {
                                grade_TextView2.setText("A");
                            }  if (totalMarks_Input >= 90 && totalMarks_Input <= 93.9) {
                                grade_TextView2.setText("A-");
                            }  if (totalMarks_Input >= 87 && totalMarks_Input <= 89.9) {
                                grade_TextView2.setText("B+");
                            }  if (totalMarks_Input >= 84 && totalMarks_Input <= 86.9) {
                                grade_TextView2.setText("B");
                            }  if (totalMarks_Input >= 80 && totalMarks_Input <= 83.9) {
                                grade_TextView2.setText("B-");
                            }  if (totalMarks_Input >= 77 && totalMarks_Input <= 79.9) {
                                grade_TextView2.setText("C+");
                            }  if (totalMarks_Input >= 74 && totalMarks_Input <= 76.9) {
                                grade_TextView2.setText("C");
                            }  if (totalMarks_Input >= 70 && totalMarks_Input <= 73.9) {
                                grade_TextView2.setText("C-");
                            }  if (totalMarks_Input >= 67 && totalMarks_Input <= 69.9) {
                                grade_TextView2.setText("D+");
                            }  if (totalMarks_Input >= 60 && totalMarks_Input <= 66.9) {
                                grade_TextView2.setText("D");
                            } if (totalMarks_Input<=59.9) {
                                grade_TextView2.setText("F");
                            }


                            studentID_TextView.setText("Student ID");
                            courseCode_TextView.setText("Course Code");
                            totalMarks_TextView.setText("Ttoal Marks");
                            grade_TextView.setText("Grade");

                            studentID_TextView2.setText(stdID_Input);
                            courseCode_TextView2.setText(courseCode_Input);
                            totalMarks_TextView2.setText(totalMarks_EditText.getText().toString());
                        }

                    }
                }
        );
    }
}
